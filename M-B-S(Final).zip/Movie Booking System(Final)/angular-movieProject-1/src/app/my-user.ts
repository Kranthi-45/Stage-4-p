export class MyUser {
    userId:number | undefined;
    username:string | undefined;
    email: string | undefined;
    phone: string | undefined;
    gender: string | undefined;
    password:string | undefined;
    role:string | undefined;
}
